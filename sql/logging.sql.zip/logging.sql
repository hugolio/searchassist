-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 02, 2015 at 03:18 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


--
-- Database: `searchassist`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookmarks`
--

CREATE TABLE IF NOT EXISTS `bookmarks` (
`id` mediumint NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `pageid` varchar(100) NOT NULL,
  `userid` varchar(100) NOT NULL,
  `timestamp` varchar(100) NOT NULL,
  `url` varchar(500) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `position` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
`id` mediumint NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `category` varchar(30) NOT NULL,
  `userid` varchar(30) NOT NULL,
  `timestamp` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
`id` mediumint NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `event` varchar(25) NOT NULL,
  `timestamp` varchar(30) NOT NULL,
  `userid` varchar(10) NOT NULL,
  `value` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
